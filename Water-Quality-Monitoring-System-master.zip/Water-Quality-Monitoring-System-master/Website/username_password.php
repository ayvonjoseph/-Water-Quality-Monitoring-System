<?php
//An external file for storing the credentials for accessing database
$username = ""; 
$password = "";
$database = "";
$server = ""; //Insert your credentials here
/*WARNING: MAKE SURE NO EMPTY LINE IS AROUND AFTER ?> SIGN*/
?>
